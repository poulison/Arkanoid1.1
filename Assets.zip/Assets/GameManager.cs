using UnityEngine;
using TMPro;
using UnityEngine.UI;
using UnityEngine.SceneManagement;



public class GameManager : MonoBehaviour
{   
    public static GameManager instance;

    private int totalBricks;

    [Header("Game Settings")]
    public int lives = 3;
    public int score = 0;

    [Header("UI")]
    public Image[] hearts;
    public TextMeshProUGUI scoreText;

    private void Awake()
{
    if (instance == null)
    {
        instance = this;
    }
    else
    {
        Destroy(gameObject);
    }
}

    private void Start()
    {
        UpdateUI();
        totalBricks = FindObjectsByType<Brick>(FindObjectsSortMode.None).Length;
    }

    public void AddScore(int amount)
    {
        score += amount;
        UpdateUI();
    }

    public void LoseLife()
    {
        lives--;

        if (lives < 0)
            lives = 0;

        UpdateUI();

        if (lives == 0)
        {
            PlayerPrefs.SetInt("LastScene", UnityEngine.SceneManagement.SceneManager.GetActiveScene().buildIndex);
            PlayerPrefs.SetInt("FinalScore", score);
            UnityEngine.SceneManagement.SceneManager.LoadScene("GameOver");

        }
    }

    private void UpdateUI()
    {
        if (scoreText != null)
            scoreText.text = "Score: " + score;

        if (hearts != null)
        {
            for (int i = 0; i < hearts.Length; i++)
            {
                hearts[i].enabled = i < lives;
            }
        }
    }

public void BrickDestroyed()
{
    totalBricks--;

    if (totalBricks <= 0)
    {
        PlayerPrefs.SetInt("AccumulatedScore", score);
        SceneManager.LoadScene("cena_2");
        Invoke(nameof(LoadNextLevel), 1f);
    }
}

void LoadNextLevel()
{
    int currentIndex = SceneManager.GetActiveScene().buildIndex;

    if (currentIndex + 1 < SceneManager.sceneCountInBuildSettings)
        SceneManager.LoadScene(currentIndex + 1);
    else
        SceneManager.LoadScene("Menu");
}

}